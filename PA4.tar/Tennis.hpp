// CSE 101 Winter 2018, PA 4
//
// You may add helper methods and include statements here, 
// but do not modify the base function signature.

#ifndef __TENNIS_HPP__
#define __TENNIS_HPP__

#include <vector>
#include <algorithm>
#include "Interval.hpp"

int tennis(std::vector<Interval> lessons);

#endif
