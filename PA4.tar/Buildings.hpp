// CSE 101 Winter 2018, PA 4
//
// You may add helper methods and include statements here, 
// but do not modify the base function signature.

#ifndef __BUILDINGS_HPP__
#define __BUILDINGS_HPP__

#include "TwoD_Array.hpp"
#include <stack>
#include <utility>
using namespace std;

int buildings(TwoD_Array<int> survey);

#endif
